package com.dao;
import com.code.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;

import webPro.SysUser;

import com.util.ConfigUtil;

public class UserDaoImpl extends BaseDao implements UserDao {
		
	//@Override
	public SysUser login(String userName, String password) throws ClassNotFoundException {
		SysUser user = null;

		String sql = "SELECT * FROM class WHERE "
				+ "num = ?"
				+ "and name = ?";		
		try {
			
			encrypt jiem= new encrypt();
			userName = jiem.jiam(userName);
			password = jiem.jiam(password);
			Object [] objs = {userName,password};
			
			super.rs = super.execQuery(sql, objs);
			if(rs.next()){
				user = new SysUser();
				user.setUsrNickname(rs.getString("num"));
				user.setUsrPassword(rs.getString("name"));
				//user.setUsrName(rs.getString("usr_name"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			//释放资源
			try {
				super.closeResource();
			} catch (SQLException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
		}
		return user;
	}
	public boolean register(String userName, String password) throws ClassNotFoundException {
		SysUser user = null;
		boolean bo=false;
		String sql = "insert into class values(?,?,?)";	
		encrypt enc = new encrypt();
		userName = enc.jiam(userName);
		password = enc.jiam(password);
		try {
			
			Object [] objs = {userName,password,1};
			
			bo = super.execUpdate(sql, objs);
			/*if(rs.next()){
				user = new SysUser();
				user.setUsrNickname(rs.getString("num"));
				user.setUsrPassword(rs.getString("name"));
				//user.setUsrName(rs.getString("usr_name"));
			}*/
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			//释放资源
			try {
				super.closeResource();
			} catch (SQLException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
		}
		return bo;
	}
}
