package com.dao;

import webPro.SysUser;

public interface UserDao {
	
	public SysUser login(String userName,String password) throws ClassNotFoundException ;
	public boolean register(String userName, String password) throws ClassNotFoundException; 
}
